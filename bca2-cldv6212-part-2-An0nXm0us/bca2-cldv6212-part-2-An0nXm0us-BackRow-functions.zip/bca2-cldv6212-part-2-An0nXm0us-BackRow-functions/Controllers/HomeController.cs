
using Azure.Data.Tables;
using CustomerInfoApp.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using Azure;

namespace CustomerInfoApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfiguration _configuration;

        public HomeController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // GET: Home/Index 
        public async Task<IActionResult> Index()
        {
            string connectionString =_configuration.GetConnectionString("AzureTableStorage");
            var tableClient = new TableClient(connectionString, "Customers");
            await tableClient.CreateIfNotExistsAsync();

            List<CustomerEntity> customers = new List<CustomerEntity>();
            await foreach (var customer in tableClient.QueryAsync<CustomerEntity>())
            {
                customers.Add(customer);
            }

            return View(customers);
        }

        // GET: Home/Create 
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Home/Create 
        [HttpPost]
        public async Task<IActionResult> Create(CustomerEntity customer)
        {
            if (ModelState.IsValid)
            {
                string connectionString =_configuration.GetConnectionString("AzureTableStorage");
                var tableClient = new TableClient(connectionString, "Customers");
                await tableClient.CreateIfNotExistsAsync();
                await tableClient.AddEntityAsync(customer);

                TempData["SuccessMessage"] = "Customer information successfully stored!"; 
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }

        // GET: Home/Edit/{rowKey} 
        [HttpGet]
        public async Task<IActionResult> Edit(string rowKey)
        {
            if (string.IsNullOrEmpty(rowKey))
            {
                TempData["ErrorMessage"] = "Invalid customer ID.";
                return RedirectToAction(nameof(Index));
            }

            try
            {
                string connectionString =_configuration.GetConnectionString("AzureTableStorage");
                var tableClient = new TableClient(connectionString, "Customers");

                var customer = await tableClient.GetEntityAsync<CustomerEntity>("Customer", rowKey);

                if (customer == null)
                {
                    TempData["ErrorMessage"] = "Customer not found.";
                    return RedirectToAction(nameof(Index));
                }

                return View(customer.Value); // Send customer data to Edit view 
            }
            catch (RequestFailedException)
            {
                TempData["ErrorMessage"] = "An error occurred while retrieving customer information."; 
                return RedirectToAction(nameof(Index));
            }
        }

        // POST: Home/Edit 
        [HttpPost]
        public async Task<IActionResult> Edit(CustomerEntity updatedCustomer)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    string connectionString =_configuration.GetConnectionString("AzureTableStorage");
                    var tableClient = new TableClient(connectionString, "Customers");

                    await tableClient.UpsertEntityAsync(updatedCustomer,TableUpdateMode.Replace);
                    TempData["SuccessMessage"] = "Customer information successfully updated!"; 
                    return RedirectToAction(nameof(Index));
                }
                catch (RequestFailedException)
                {
                    TempData["ErrorMessage"] = "An error occurred while updating customer information."; 
                    return View(updatedCustomer);
                }
            }
            return View(updatedCustomer);
        }

        // GET: Home/Delete/{rowKey} 
        [HttpGet]
        public async Task<IActionResult> Delete(string rowKey)
        {
            if (string.IsNullOrEmpty(rowKey))
            {
                TempData["ErrorMessage"] = "Invalid customer ID.";
                return RedirectToAction(nameof(Index));
            }

            try
            {
                string connectionString =_configuration.GetConnectionString("AzureTableStorage");
                var tableClient = new TableClient(connectionString, "Customers");

                var customer = await tableClient.GetEntityAsync<CustomerEntity>("Customer", rowKey);
                if (customer == null)
                {
                    TempData["ErrorMessage"] = "Customer not found.";
                    return RedirectToAction(nameof(Index));
                }

                return View(customer.Value); // Send customer data to Delete view 
            }
            catch (RequestFailedException)
            {
                TempData["ErrorMessage"] = "An error occurred while retrieving customer information."; 
                return RedirectToAction(nameof(Index));
            }
        }

        // POST: Home/Delete/{rowKey} 
        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(string rowKey)
        {
            try
            {
                string connectionString =_configuration.GetConnectionString("AzureTableStorage");
                var tableClient = new TableClient(connectionString, "Customers");

                await tableClient.DeleteEntityAsync("Customer", rowKey);
                TempData["SuccessMessage"] = "Customer information successfully deleted!"; 
                return RedirectToAction(nameof(Index));
            }
            catch (RequestFailedException)
            {
                TempData["ErrorMessage"] = "An error occurred while deleting customer information."; 
                return RedirectToAction(nameof(Index));
            }
        }
    }
}